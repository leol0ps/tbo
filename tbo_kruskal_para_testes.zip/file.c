#define  _POSIX_C_SOURCE 200809L
#include "file.h"

int contador_de_virgulas(char* line){
    int size = strlen(line)+1;
    int ret = 0;
    for(int i = 0 ; i < size;i++){
        if(line[i]==',')
            ret++;
    }
    return ret;
}
List* read_file(char* path, int* dimension,int* lines){
    List* a = NULL;
    FILE * fp = NULL;
    char * line = NULL;
    Point* ponto = NULL;
    size_t len = 0;
    ssize_t read;
    char* aux = NULL;
    int number_of_lines = 0;
    int number_of_arguments = 0;
    char* name = NULL;
    fp = fopen(path, "r");
    if (fp == NULL){
        printf("sem arquivo\n");
        return NULL;
    }
    read = (getline(&line, &len, fp) != -1);
    number_of_lines++;
    number_of_arguments= contador_de_virgulas(line); 
    /*while ((read = getline(&line, &len, fp)) != -1){
        aux = strtok(line,",");
        while(aux!=0){
            printf("%s\n",aux);
            aux=strtok(0,",");
        }
    }
    printf("%d\n",number_of_arguments);*/
    int i = 0;
    double* posit = malloc(number_of_arguments*sizeof(double));
    for(int j = 0; j < number_of_arguments; j++){
        posit[j] = 0;
    }
    aux = strtok(line,",\n\0");
    //name = aux;
    int name_point = 0;
    while (aux != NULL && i < number_of_arguments){
        if(name_point==0){
                name = aux;
                name_point = 1;
        }
        else{
                posit[i] = atof(aux);
                i++;
        }
        
        aux = strtok (NULL, ",\n\0");
    }

    ponto = create_point(number_of_arguments,name,posit);
    a = create_list(ponto);
    ponto = NULL;
    while ((read = getline(&line, &len, fp)) != -1) {
        i = 0;
        name_point = 0;
        aux = strtok(line,",\n\0");
        while (aux != NULL && i < number_of_arguments+1){
            if(name_point==0){
                name = aux;
                name_point = 1;
            }
            else{
                posit[i] = atof(aux);
                i++;
            }
            aux = strtok (NULL, ",\n\0");
        }
        ponto = create_point(number_of_arguments,name,posit);
        insert(a,ponto);
        ponto = NULL;
        number_of_lines++;
    }
    
    *dimension = number_of_arguments;
    *lines = number_of_lines;
    free(posit);
    free(line); //getline aloca memoria
    fclose(fp);
    return a;
}

void write_file(Point** vetor, int size, int k,char* filename){
    FILE* out = NULL;
    out = fopen(filename,"w"); 
    if(out == NULL){
		fprintf(stderr,"error opening %s\n", filename);
		return;
	}
    print_to_file(vetor,size,k,out);
    fclose(out);
}