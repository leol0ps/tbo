#ifndef FILE_H
#define FILE_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "list.h"
#include "point.h"
List* read_file(char* path, int* dimension, int* lines);
void write_file(Point** vetor, int size, int k,char* filename);



#endif